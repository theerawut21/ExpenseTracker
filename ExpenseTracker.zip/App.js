import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Provider as PaperProvider } from 'react-native-paper';
import { SafeAreaProvider } from 'react-native-safe-area-context';

// Import screens
import HomeScreen from './src/screens/HomeScreen';
import AddTransactionScreen from './src/screens/AddTransactionScreen';
import StatisticsScreen from './src/screens/StatisticsScreen';
import SavingGoalsScreen from './src/screens/SavingGoalsScreen';

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

const theme = {
  colors: {
    primary: '#6200ee',
    accent: '#03dac4',
    background: '#f6f6f6',
    surface: '#ffffff',
    text: '#000000',
    error: '#B00020',
  },
};

const HomeStack = () => (
  <Stack.Navigator>
    <Stack.Screen 
      name="Home" 
      component={HomeScreen} 
      options={{ headerShown: false }}
    />
    <Stack.Screen 
      name="AddTransaction" 
      component={AddTransactionScreen}
      options={{ title: 'Add Transaction' }}
    />
  </Stack.Navigator>
);

const MainApp = () => (
  <Tab.Navigator
    screenOptions={({ route }) => ({
      tabBarIcon: ({ focused, color, size }) => {
        let iconName;

        if (route.name === 'Home') {
          iconName = focused ? 'home' : 'home-outline';
        } else if (route.name === 'Transactions') {
          iconName = focused ? 'format-list-bulleted' : 'format-list-bulleted';
        } else if (route.name === 'Statistics') {
          iconName = focused ? 'chart-bar' : 'chart-bar';
        } else if (route.name === 'Goals') {
          iconName = focused ? 'piggy-bank' : 'piggy-bank-outline';
        }

        return <MaterialCommunityIcons name={iconName} size={size} color={color} />;
      },
    })}
  >
    <Tab.Screen 
      name="Home" 
      component={HomeStack}
      options={{ headerShown: false }}
    />
    <Tab.Screen 
      name="Statistics" 
      component={StatisticsScreen}
      options={{ title: 'Statistics' }}
    />
    <Tab.Screen 
      name="Goals" 
      component={SavingGoalsScreen}
      options={{ title: 'Saving Goals' }}
    />
  </Tab.Navigator>
);

const App = () => {
  return (
    <SafeAreaProvider>
      <PaperProvider theme={theme}>
        <NavigationContainer>
          <MainApp />
        </NavigationContainer>
      </PaperProvider>
    </SafeAreaProvider>
  );
};

export default App;
