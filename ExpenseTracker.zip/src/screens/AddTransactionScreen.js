import React, { useState } from 'react';
import { View, StyleSheet, ScrollView } from 'react-native';
import { TextInput, Button, Text, Surface, SegmentedButtons, useTheme } from 'react-native-paper';
import AsyncStorage from '@react-native-async-storage/async-storage';

const categories = {
  expense: [
    'Food & Drinks',
    'Shopping',
    'Transport',
    'Entertainment',
    'Bills',
    'Health',
    'Education',
    'Other'
  ],
  income: [
    'Salary',
    'Business',
    'Investments',
    'Freelance',
    'Gift',
    'Other'
  ]
};

const AddTransactionScreen = ({ navigation }) => {
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [category, setCategory] = useState('');
  const [type, setType] = useState('expense');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const theme = useTheme();

  const handleSave = async () => {
    if (!amount || !category) {
      setError('Please fill in all required fields');
      return;
    }

    if (isNaN(amount) || parseFloat(amount) <= 0) {
      setError('Please enter a valid amount');
      return;
    }

    setLoading(true);
    try {
      const transaction = {
        id: Date.now().toString(),
        amount: parseFloat(amount),
        category,
        note,
        type,
        date: new Date().toISOString(),
      };

      const storedTransactions = await AsyncStorage.getItem('transactions');
      const transactions = storedTransactions ? JSON.parse(storedTransactions) : [];
      transactions.unshift(transaction);
      await AsyncStorage.setItem('transactions', JSON.stringify(transactions));

      navigation.goBack();
    } catch (error) {
      setError('Failed to save transaction');
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView style={styles.container} keyboardShouldPersistTaps="handled">
      <Surface style={styles.card}>
        <Text style={styles.title}>Add Transaction</Text>

        <SegmentedButtons
          value={type}
          onValueChange={(value) => {
            setType(value);
            setCategory('');
          }}
          buttons={[
            {
              value: 'expense',
              label: 'Expense',
              icon: 'minus-circle',
              style: type === 'expense' ? styles.segmentSelected : styles.segmentUnselected,
              labelStyle: type === 'expense' ? styles.segmentLabelSelected : styles.segmentLabelUnselected,
              iconColor: type === 'expense' ? '#fff' : '#6200ee',
            },
            {
              value: 'income',
              label: 'Income',
              icon: 'plus-circle',
              style: type === 'income' ? styles.segmentSelected : styles.segmentUnselected,
              labelStyle: type === 'income' ? styles.segmentLabelSelected : styles.segmentLabelUnselected,
              iconColor: type === 'income' ? '#fff' : '#6200ee',
            }
          ]}
          style={styles.segmentedButtons}
        />

        <TextInput
          label="Amount"
          value={amount}
          onChangeText={setAmount}
          keyboardType="numeric"
          style={styles.input}
          mode="outlined"
          left={<TextInput.Icon icon="cash" />}
          placeholder=""
        />

        <Text style={styles.label}>Select Category</Text>
        <View style={styles.categoryContainer}>
          {categories[type].map((cat) => (
            <Button
              key={cat}
              mode={category === cat ? 'contained' : 'outlined'}
              onPress={() => setCategory(cat)}
              style={[
                styles.categoryButton,
                category === cat && styles.selectedCategory
              ]}
              labelStyle={[
                styles.categoryButtonLabel,
                category === cat && styles.selectedCategoryLabel
              ]}
              compact
            >
              {cat}
            </Button>
          ))}
        </View>

        <TextInput
          label="Note (optional)"
          value={note}
          onChangeText={setNote}
          style={styles.input}
          mode="outlined"
          multiline
          numberOfLines={3}
          left={<TextInput.Icon icon="note" />}
          placeholder="Add a short note"
        />

        {error ? <Text style={styles.error}>{error}</Text> : null}

        <Button
          mode="contained"
          onPress={handleSave}
          style={styles.saveButton}
          loading={loading}
          disabled={loading}
        >
          Save Transaction
        </Button>
      </Surface>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f6f6f6',
  },
  card: {
    margin: 16,
    padding: 24,
    borderRadius: 16,
    elevation: 4,
    backgroundColor: '#ffffff',
  },
  title: {
    fontSize: 24,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 24,
    color: '#6200ee',
  },
  segmentedButtons: {
    marginBottom: 24,
  },
  segmentSelected: {
    backgroundColor: '#6200ee',
    borderRadius: 20,
  },
  segmentUnselected: {
    backgroundColor: '#fff',
    borderRadius: 20,
  },
  segmentLabelSelected: {
    color: '#fff',
    fontWeight: '600',
  },
  segmentLabelUnselected: {
    color: '#6200ee',
    fontWeight: '500',
  },
  input: {
    marginBottom: 16,
    backgroundColor: '#fff',
  },
  label: {
    fontSize: 16,
    fontWeight: '500',
    marginBottom: 8,
    color: '#333',
  },
  categoryContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  categoryButton: {
    marginBottom: 10,
    flexGrow: 1,
    marginRight: 8,
    borderRadius: 20,
    borderColor: '#ccc',
  },
  selectedCategory: {
    backgroundColor: '#6200ee',
    borderColor: '#6200ee',
  },
  categoryButtonLabel: {
    fontSize: 13,
    textAlign: 'center',
    color: '#555',
  },
  selectedCategoryLabel: {
    color: '#fff',
  },
  saveButton: {
    marginTop: 10,
    paddingVertical: 10,
    borderRadius: 24,
  },
  error: {
    color: 'red',
    textAlign: 'center',
    marginTop: 10,
  },
});

export default AddTransactionScreen;
