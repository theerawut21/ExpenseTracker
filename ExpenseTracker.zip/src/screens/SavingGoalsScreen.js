import React, { useState, useEffect } from 'react';
import { View, StyleSheet, ScrollView, Alert } from 'react-native';
import { Text, Card, Button, TextInput, ProgressBar, Portal, Modal, FAB } from 'react-native-paper';
import AsyncStorage from '@react-native-async-storage/async-storage';

const SavingGoalsScreen = () => {
  const [goals, setGoals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [editingGoal, setEditingGoal] = useState(null);
  const [formData, setFormData] = useState({
    title: '',
    targetAmount: '',
    currentAmount: '',
    deadline: '',
  });

  useEffect(() => {
    loadGoals();
  }, []);

  const loadGoals = async () => {
    try {
      const storedGoals = await AsyncStorage.getItem('savingGoals');
      if (storedGoals) {
        setGoals(JSON.parse(storedGoals));
      }
      setLoading(false);
    } catch (error) {
      console.error('Error loading goals:', error);
      setLoading(false);
    }
  };

  const saveGoal = async () => {
    try {
      const newGoal = {
        id: editingGoal?.id || Date.now().toString(),
        title: formData.title,
        targetAmount: parseFloat(formData.targetAmount),
        currentAmount: parseFloat(formData.currentAmount),
        deadline: formData.deadline,
        createdAt: editingGoal?.createdAt || new Date().toISOString(),
      };

      const updatedGoals = editingGoal
        ? goals.map(goal => goal.id === editingGoal.id ? newGoal : goal)
        : [...goals, newGoal];

      await AsyncStorage.setItem('savingGoals', JSON.stringify(updatedGoals));
      setGoals(updatedGoals);
      setModalVisible(false);
      resetForm();
    } catch (error) {
      console.error('Error saving goal:', error);
      Alert.alert('Error', 'Failed to save goal');
    }
  };

  const deleteGoal = async (id) => {
    try {
      const updatedGoals = goals.filter(goal => goal.id !== id);
      await AsyncStorage.setItem('savingGoals', JSON.stringify(updatedGoals));
      setGoals(updatedGoals);
    } catch (error) {
      console.error('Error deleting goal:', error);
      Alert.alert('Error', 'Failed to delete goal');
    }
  };

  const resetForm = () => {
    setFormData({
      title: '',
      targetAmount: '',
      currentAmount: '',
      deadline: '',
    });
    setEditingGoal(null);
  };

  const openEditModal = (goal) => {
    setEditingGoal(goal);
    setFormData({
      title: goal.title,
      targetAmount: goal.targetAmount.toString(),
      currentAmount: goal.currentAmount.toString(),
      deadline: goal.deadline,
    });
    setModalVisible(true);
  };

  const calculateProgress = (current, target) => {
    return Math.min(current / target, 1);
  };

  const formatCurrency = (amount) => {
    return `${amount.toLocaleString()}฿`;
  };

  return (
    <View style={styles.container}>
      <ScrollView style={styles.scrollView}>
        {goals.map((goal) => (
          <Card key={goal.id} style={styles.card}>
            <Card.Content>
              <View style={styles.goalHeader}>
                <Text style={styles.goalTitle}>{goal.title}</Text>
                <View style={styles.goalActions}>
                  <Button
                    icon="pencil"
                    onPress={() => openEditModal(goal)}
                    mode="text"
                  >
                    Edit
                  </Button>
                  <Button
                    icon="delete"
                    onPress={() => deleteGoal(goal.id)}
                    mode="text"
                    textColor="red"
                  >
                    Delete
                  </Button>
                </View>
              </View>
              <View style={styles.progressContainer}>
                <Text style={styles.amountText}>
                  {formatCurrency(goal.currentAmount)} / {formatCurrency(goal.targetAmount)}
                </Text>
                <ProgressBar
                  progress={calculateProgress(goal.currentAmount, goal.targetAmount)}
                  color="#4CAF50"
                  style={styles.progressBar}
                />
                <Text style={styles.deadlineText}>
                  Deadline: {new Date(goal.deadline).toLocaleDateString()}
                </Text>
              </View>
            </Card.Content>
          </Card>
        ))}
      </ScrollView>

      <Portal>
        <Modal
          visible={modalVisible}
          onDismiss={() => {
            setModalVisible(false);
            resetForm();
          }}
          contentContainerStyle={styles.modalContent}
        >
          <Text style={styles.modalTitle}>
            {editingGoal ? 'Edit Goal' : 'New Saving Goal'}
          </Text>
          <TextInput
            label="Goal Title"
            value={formData.title}
            onChangeText={(text) => setFormData({ ...formData, title: text })}
            style={styles.input}
          />
          <TextInput
            label="Target Amount"
            value={formData.targetAmount}
            onChangeText={(text) => setFormData({ ...formData, targetAmount: text })}
            keyboardType="numeric"
            style={styles.input}
          />
          <TextInput
            label="Current Amount"
            value={formData.currentAmount}
            onChangeText={(text) => setFormData({ ...formData, currentAmount: text })}
            keyboardType="numeric"
            style={styles.input}
          />
          <TextInput
            label="Deadline"
            value={formData.deadline}
            onChangeText={(text) => setFormData({ ...formData, deadline: text })}
            placeholder="YYYY-MM-DD"
            style={styles.input}
          />
          <Button
            mode="contained"
            onPress={saveGoal}
            style={styles.saveButton}
          >
            Save Goal
          </Button>
        </Modal>
      </Portal>

      <FAB
        icon="plus"
        style={styles.fab}
        onPress={() => {
          resetForm();
          setModalVisible(true);
        }}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  scrollView: {
    flex: 1,
    padding: 16,
  },
  card: {
    marginBottom: 16,
    elevation: 2,
  },
  goalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  goalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  goalActions: {
    flexDirection: 'row',
  },
  progressContainer: {
    marginTop: 8,
  },
  amountText: {
    fontSize: 16,
    marginBottom: 4,
  },
  progressBar: {
    height: 8,
    borderRadius: 4,
    marginVertical: 8,
  },
  deadlineText: {
    fontSize: 14,
    color: '#666',
  },
  modalContent: {
    backgroundColor: 'white',
    padding: 20,
    margin: 20,
    borderRadius: 8,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  input: {
    marginBottom: 16,
  },
  saveButton: {
    marginTop: 8,
  },
  fab: {
    position: 'absolute',
    margin: 16,
    right: 0,
    bottom: 0,
  },
});

export default SavingGoalsScreen; 