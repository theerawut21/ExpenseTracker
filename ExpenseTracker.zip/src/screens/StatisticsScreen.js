import React, { useState, useEffect, useCallback } from 'react';
import { View, StyleSheet, ScrollView, Dimensions, Platform } from 'react-native';
import { Text, Card, Divider, ActivityIndicator, Surface } from 'react-native-paper';
import { LineChart, PieChart } from 'react-native-chart-kit';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect } from '@react-navigation/native';

// Theme colors
const theme = {
  primary: '#6366f1',
  secondary: '#f59e0b',
  success: '#10b981',
  error: '#ef4444',
  background: '#f8fafc',
  surface: '#ffffff',
  text: {
    primary: '#1e293b',
    secondary: '#64748b',
    light: '#94a3b8',
  },
  chart: {
    income: '#10b981',
    expense: '#ef4444',
  }
};

const getScreenWidth = () => {
  if (Platform.OS === 'web') {
    return Math.min(window.innerWidth - 40, 800);
  }
  return Dimensions.get('window').width - 40;
};

const StatisticsScreen = () => {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [screenWidth, setScreenWidth] = useState(getScreenWidth());
  const [totalIncome, setTotalIncome] = useState(0);
  const [totalExpense, setTotalExpense] = useState(0);

  useEffect(() => {
    loadTransactions();

    if (Platform.OS === 'web') {
      const handleResize = () => {
        setScreenWidth(getScreenWidth());
      };
      window.addEventListener('resize', handleResize);
      return () => window.removeEventListener('resize', handleResize);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      loadTransactions(); // โหลดใหม่เมื่อกลับมาหน้านี้
    }, [])
  );

  const loadTransactions = async () => {
    try {
      const storedTransactions = await AsyncStorage.getItem('transactions');
      if (storedTransactions) {
        const parsed = JSON.parse(storedTransactions);
        setTransactions(parsed);

        const income = parsed.reduce((sum, t) => t.type === 'income' ? sum + t.amount : sum, 0);
        const expense = parsed.reduce((sum, t) => t.type === 'expense' ? sum + t.amount : sum, 0);
        setTotalIncome(income);
        setTotalExpense(expense);
      } else {
        setTransactions([]);
        setTotalIncome(0);
        setTotalExpense(0);
      }
      setLoading(false);
    } catch (error) {
      console.error('Error loading transactions:', error);
      setLoading(false);
    }
  };

  const getMonthlyData = () => {
    const monthlyData = {};
    transactions.forEach((transaction) => {
      const month = new Date(transaction.date).toLocaleString('default', { month: 'short' });
      if (!monthlyData[month]) {
        monthlyData[month] = { income: 0, expense: 0 };
      }
      if (transaction.type === 'income') {
        monthlyData[month].income += transaction.amount;
      } else {
        monthlyData[month].expense += transaction.amount;
      }
    });

    const labels = Object.keys(monthlyData);
    const incomeData = labels.map((month) => monthlyData[month].income);
    const expenseData = labels.map((month) => monthlyData[month].expense);

    return { labels, incomeData, expenseData };
  };

  const getCategoryData = () => {
    const categoryData = {};
    transactions.forEach((transaction) => {
      if (transaction.type === 'expense') {
        if (!categoryData[transaction.category]) {
          categoryData[transaction.category] = 0;
        }
        categoryData[transaction.category] += transaction.amount;
      }
    });

    const colors = [
      '#6366f1', '#f59e0b', '#10b981', '#ec4899',
      '#8b5cf6', '#14b8a6', '#f43f5e', '#06b6d4',
    ];

    return Object.entries(categoryData).map(([name, amount], index) => ({
      name,
      amount,
      color: colors[index % colors.length],
      legendFontColor: theme.text.primary,
      legendFontSize: 12,
    }));
  };

  if (loading) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: theme.background }]}>
        <ActivityIndicator size="large" color={theme.primary} />
        <Text style={[styles.loadingText, { color: theme.text.secondary }]}>Loading statistics...</Text>
      </View>
    );
  }

  if (transactions.length === 0) {
    return (
      <View style={[styles.emptyContainer, { backgroundColor: theme.background }]}>
        <Text style={[styles.emptyText, { color: theme.text.primary }]}>No transactions found</Text>
        <Text style={[styles.emptySubText, { color: theme.text.secondary }]}>
          Add some transactions to see your statistics
        </Text>
      </View>
    );
  }

  const { labels, incomeData, expenseData } = getMonthlyData();
  const categoryData = getCategoryData();

  return (
    <ScrollView style={[styles.container, { backgroundColor: theme.background }]} contentContainerStyle={styles.contentContainer}>
      {/* Summary Cards */}
      <View style={styles.summaryContainer}>
        <Surface style={[styles.summaryCard, { backgroundColor: theme.surface }]}>
          <Text style={[styles.summaryLabel, { color: theme.text.secondary }]}>Total Income</Text>
          <Text style={[styles.summaryAmount, { color: theme.chart.income }]}>
            {totalIncome.toLocaleString()}฿
          </Text>
        </Surface>
        <Surface style={[styles.summaryCard, { backgroundColor: theme.surface }]}>
          <Text style={[styles.summaryLabel, { color: theme.text.secondary }]}>Total Expense</Text>
          <Text style={[styles.summaryAmount, { color: theme.chart.expense }]}>
            {totalExpense.toLocaleString()}฿
          </Text>
        </Surface>
        <Surface style={[styles.summaryCard, { backgroundColor: theme.surface }]}>
          <Text style={[styles.summaryLabel, { color: theme.text.secondary }]}>Balance</Text>
          <Text style={[styles.summaryAmount, { color: totalIncome - totalExpense >= 0 ? theme.chart.income : theme.chart.expense }]}>
            {(totalIncome - totalExpense).toLocaleString()}฿
          </Text>
        </Surface>
      </View>

      {/* Monthly Overview */}
      <Card style={[styles.card, { backgroundColor: theme.surface }]}>
        <Card.Content>
          <Text style={[styles.title, { color: theme.text.primary }]}>Monthly Overview</Text>
          <Divider style={[styles.divider, { backgroundColor: theme.text.light }]} />
          {Platform.OS === 'web' ? (
            <View style={styles.webChartContainer}>
              <View style={styles.dataContainer}>
                {labels.map((month, index) => (
                  <Surface key={month} style={[styles.dataRow, { backgroundColor: theme.surface }]}>
                    <View style={styles.monthContainer}>
                      <Text style={[styles.monthText, { color: theme.text.primary }]}>{month}</Text>
                    </View>
                    <View style={styles.amountContainer}>
                      <View style={styles.amountRow}>
                        <Text style={[styles.amountLabel, { color: theme.text.secondary }]}>Income:</Text>
                        <Text style={[styles.incomeText, { color: theme.chart.income }]}>
                          {incomeData[index].toLocaleString()}฿
                        </Text>
                      </View>
                      <View style={styles.amountRow}>
                        <Text style={[styles.amountLabel, { color: theme.text.secondary }]}>Expense:</Text>
                        <Text style={[styles.expenseText, { color: theme.chart.expense }]}>
                          {expenseData[index].toLocaleString()}฿
                        </Text>
                      </View>
                    </View>
                  </Surface>
                ))}
              </View>
            </View>
          ) : (
            <LineChart
              data={{
                labels,
                datasets: [
                  {
                    data: incomeData,
                    color: (opacity = 1) => `rgba(16, 185, 129, ${opacity})`,
                    strokeWidth: 3,
                  },
                  {
                    data: expenseData,
                    color: (opacity = 1) => `rgba(239, 68, 68, ${opacity})`,
                    strokeWidth: 3,
                  },
                ],
              }}
              width={screenWidth}
              height={280}
              chartConfig={{
                backgroundColor: theme.surface,
                backgroundGradientFrom: theme.surface,
                backgroundGradientTo: theme.surface,
                decimalPlaces: 0,
                color: (opacity = 1) => `rgba(30, 41, 59, ${opacity})`,
                style: {
                  borderRadius: 16,
                },
                propsForDots: {
                  r: "6",
                  strokeWidth: "2",
                },
              }}
              bezier
              style={styles.chart}
            />
          )}
        </Card.Content>
      </Card>

      {/* Expense Categories */}
      <Card style={[styles.card, { backgroundColor: theme.surface }]}>
        <Card.Content>
          <Text style={[styles.title, { color: theme.text.primary }]}>Expense Categories</Text>
          <Divider style={[styles.divider, { backgroundColor: theme.text.light }]} />
          {Platform.OS === 'web' ? (
            <View style={styles.webChartContainer}>
              <View style={styles.dataContainer}>
                {categoryData.map((category) => (
                  <Surface key={category.name} style={[styles.categoryRow, { backgroundColor: theme.surface }]}>
                    <View style={styles.categoryInfo}>
                      <View style={[styles.colorDot, { backgroundColor: category.color }]} />
                      <Text style={[styles.categoryText, { color: theme.text.primary }]}>{category.name}</Text>
                    </View>
                    <Text style={[styles.amountText, { color: theme.text.primary }]}>
                      {category.amount.toLocaleString()}฿
                    </Text>
                  </Surface>
                ))}
              </View>
            </View>
          ) : (
            <PieChart
              data={categoryData}
              width={screenWidth}
              height={280}
              chartConfig={{
                color: (opacity = 1) => `rgba(30, 41, 59, ${opacity})`,
              }}
              accessor="amount"
              backgroundColor="transparent"
              paddingLeft="15"
              absolute
            />
          )}
        </Card.Content>
      </Card>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  contentContainer: {
    padding: 16,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  emptyText: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  emptySubText: {
    fontSize: 16,
    textAlign: 'center',
  },
  summaryContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  summaryCard: {
    flex: 1,
    marginHorizontal: 8,
    padding: 16,
    borderRadius: 12,
    elevation: 2,
  },
  summaryLabel: {
    fontSize: 14,
    marginBottom: 4,
  },
  summaryAmount: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  card: {
    marginBottom: 16,
    elevation: 2,
    borderRadius: 12,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  divider: {
    marginVertical: 12,
    height: 1,
  },
  chart: {
    marginVertical: 8,
    borderRadius: 16,
  },
  webChartContainer: {
    padding: 8,
  },
  dataContainer: {
    marginTop: 8,
  },
  dataRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 16,
    borderRadius: 8,
    marginBottom: 8,
    elevation: 1,
  },
  monthContainer: {
    flex: 1,
    justifyContent: 'center',
  },
  monthText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  amountContainer: {
    flex: 2,
  },
  amountRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  amountLabel: {
    fontSize: 14,
  },
  incomeText: {
    fontSize: 14,
    fontWeight: '600',
  },
  expenseText: {
    fontSize: 14,
    fontWeight: '600',
  },
  categoryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderRadius: 8,
    marginBottom: 8,
    elevation: 1,
  },
  categoryInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  colorDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 8,
  },
  categoryText: {
    fontSize: 16,
  },
  amountText: {
    fontSize: 16,
    fontWeight: '600',
  },
});

export default StatisticsScreen; 