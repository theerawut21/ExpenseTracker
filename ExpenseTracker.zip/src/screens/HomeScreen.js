import React, { useState, useCallback } from 'react';
import { View, StyleSheet, ScrollView } from 'react-native';
import { Text, FAB, Card, Button, Surface, useTheme, IconButton } from 'react-native-paper';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect } from '@react-navigation/native'; // ✅ เพิ่มเข้ามา

const HomeScreen = ({ navigation }) => {
  const [user, setUser] = useState(null);
  const [totalExpense, setTotalExpense] = useState(0);
  const [totalIncome, setTotalIncome] = useState(0);
  const [recentTransactions, setRecentTransactions] = useState([]);
  const theme = useTheme();

  // ✅ ใช้ useFocusEffect เพื่อโหลดทุกครั้งเมื่อหน้าถูกเปิด
  useFocusEffect(
    useCallback(() => {
      loadUserData();
      loadTransactions();
    }, [])
  );

  const loadUserData = async () => {
    try {
      const userData = await AsyncStorage.getItem('user');
      if (userData) {
        setUser(JSON.parse(userData));
      }
    } catch (error) {
      console.error('Error loading user data:', error);
    }
  };

  const loadTransactions = async () => {
    try {
      const transactions = await AsyncStorage.getItem('transactions');
      if (transactions) {
        const parsedTransactions = JSON.parse(transactions);
        setRecentTransactions(parsedTransactions.slice(0, 5));

        const expense = parsedTransactions
          .filter(t => t.type === 'expense')
          .reduce((sum, t) => sum + parseFloat(t.amount), 0);
        const income = parsedTransactions
          .filter(t => t.type === 'income')
          .reduce((sum, t) => sum + parseFloat(t.amount), 0);

        setTotalExpense(expense);
        setTotalIncome(income);
      }
    } catch (error) {
      console.error('Error loading transactions:', error);
    }
  };

  const deleteTransaction = async (indexToDelete) => {
    try {
      const transactions = await AsyncStorage.getItem('transactions');
      if (transactions) {
        let parsedTransactions = JSON.parse(transactions);
        parsedTransactions.splice(indexToDelete, 1);
        await AsyncStorage.setItem('transactions', JSON.stringify(parsedTransactions));
        loadTransactions(); // รีโหลดรายการหลังลบ
      }
    } catch (error) {
      console.error('Error deleting transaction:', error);
    }
  };

  const handleLogout = async () => {
    try {
      await AsyncStorage.removeItem('isAuthenticated');
      navigation.replace('Auth');
    } catch (error) {
      console.error('Error logging out:', error);
    }
  };

  return (
    <View style={styles.container}>
      <Surface style={styles.header}>
        <View style={styles.headerContent}>
          <View>
            <Text style={styles.welcomeText}>Welcome back,</Text>
            <Text style={styles.nameText}>{user?.name || 'User'}</Text>
          </View>
          <IconButton
            icon="logout"
            size={24}
            onPress={handleLogout}
            style={styles.logoutButton}
          />
        </View>
      </Surface>

      <ScrollView style={styles.content}>
        <View style={styles.balanceCards}>
          <Card style={[styles.balanceCard, { backgroundColor: theme.colors.primary }]}>
            <Card.Content>
              <Text style={styles.balanceLabel}>Income</Text>
              <Text style={styles.balanceAmount}>{totalIncome.toFixed(2)} ฿</Text>
            </Card.Content>
          </Card>

          <Card style={[styles.balanceCard, { backgroundColor: '#ff4444' }]}>
            <Card.Content>
              <Text style={styles.balanceLabel}>Expenses</Text>
              <Text style={styles.balanceAmount}>{totalExpense.toFixed(2)} ฿</Text>
            </Card.Content>
          </Card>
        </View>

        <Card style={styles.recentTransactionsCard}>
          <Card.Title title="Recent Transactions" />
          <Card.Content>
            {recentTransactions.length > 0 ? (
              recentTransactions.map((transaction, index) => (
                <Surface key={index} style={styles.transactionItem}>
                  <View style={styles.transactionLeft}>
                    <Text style={styles.transactionCategory}>{transaction.category}</Text>
                    <Text style={styles.transactionDate}>
                      {new Date(transaction.date).toLocaleDateString()}
                    </Text>
                  </View>
                  <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Text
                      style={[
                        styles.transactionAmount,
                        {
                          color: transaction.type === 'expense' ? '#ff4444' : theme.colors.primary,
                          marginRight: 8,
                        },
                      ]}
                    >
                      {transaction.type === 'expense' ? '-' : '+'}{transaction.amount} ฿
                    </Text>
                    <IconButton
                      icon="delete"
                      size={20}
                      onPress={() => deleteTransaction(index)}
                    />
                  </View>
                </Surface>
              ))
            ) : (
              <Text style={styles.noTransactions}>No recent transactions</Text>
            )}
          </Card.Content>
        </Card>
      </ScrollView>

      <FAB
        style={styles.fab}
        icon="plus"
        onPress={() => navigation.navigate('AddTransaction')}
        label="Add Transaction"
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f6f6f6',
  },
  header: {
    padding: 16,
    elevation: 4,
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  welcomeText: {
    fontSize: 16,
    color: '#666',
  },
  nameText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#000',
  },
  logoutButton: {
    margin: 0,
  },
  content: {
    flex: 1,
    padding: 16,
  },
  balanceCards: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  balanceCard: {
    flex: 1,
    marginHorizontal: 4,
  },
  balanceLabel: {
    color: '#fff',
    fontSize: 16,
  },
  balanceAmount: {
    color: '#fff',
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: 8,
  },
  recentTransactionsCard: {
    marginBottom: 16,
  },
  transactionItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 12,
    marginBottom: 8,
    borderRadius: 8,
    elevation: 2,
  },
  transactionLeft: {
    flex: 1,
  },
  transactionCategory: {
    fontSize: 16,
    fontWeight: '500',
  },
  transactionDate: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  transactionAmount: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  noTransactions: {
    textAlign: 'center',
    color: '#666',
    padding: 16,
  },
  fab: {
    position: 'absolute',
    margin: 16,
    right: 0,
    bottom: 0,
  },
});

export default HomeScreen;
